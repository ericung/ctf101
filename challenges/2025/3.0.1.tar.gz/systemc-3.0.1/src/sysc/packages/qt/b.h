#ifndef B_H
#define B_H	"$Header: /Users/acg/CVSROOT/systemc-2.3/src/sysc/qt/b.h,v 1.1.1.1 2006/12/15 20:20:06 acg Exp $"

#include "copyright.h"

extern void b_call_reg (int n);
extern void b_call_imm (int n);
extern void b_add (int n);
extern void b_load (int n);

#endif /* ndef B_H */
